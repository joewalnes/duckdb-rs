#include "src/execution/operator/set/physical_cte.cpp"

#include "src/execution/operator/set/physical_recursive_cte.cpp"

#include "src/execution/operator/set/physical_recursive_cte_runtime.cpp"

#include "src/execution/operator/set/physical_union.cpp"

